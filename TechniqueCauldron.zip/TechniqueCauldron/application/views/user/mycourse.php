<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="<?php echo base_url("assets/bootstrap-3.3.7/css/bootstrap.css")?>">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="<?php echo base_url("assets/bootstrap-3.3.7/js/bootstrap.min.js")?>"></script>
</head>
<body>
    <div class="jumbotron">
        <div class="container text-center">
            <h1>Techniq Cauldron</h1>
            <p>Learn here anything</p>
        </div>
    </div>
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="#">Cauldron</a>
            </div>
            <ul class="nav navbar-nav">
                <li class="active"><a href="<?php echo site_url("user");?>">Home</a></li>
                <li><a href="<?php echo site_url("course/catalog");?>">Catalog</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="<?php echo site_url("user/myaccount");?>"><span class="glyphicon glyphicon-user"></span> My Account</a></li>
                <li><a href="<?php echo site_url("user/logout");?>"><span></span> Logout</a></li>
            </ul>
        </div>
    </nav>
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <div class="panel panel-primary">
                    <div class="panel-heading">Course 1</div>
                    <div class="panel-body"><img src="<?php echo base_url("images/test.png")?>" class="img-responsive" style="width:100%" alt="Image"></div>
                    <div class="panel-footer">John Rambo</div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="panel panel-primary">
                    <div class="panel-heading">Course 2</div>
                    <div class="panel-body"><img src="<?php echo base_url("images/test.png")?>" class="img-responsive" style="width:100%" alt="Image"></div>
                    <div class="panel-footer">Rocky Balboa</div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
