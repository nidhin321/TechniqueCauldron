<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="<?php echo base_url("assets/bootstrap-3.3.7/css/bootstrap.css")?>">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="<?php echo base_url("assets/bootstrap-3.3.7/js/bootstrap.min.js")?>"></script>
</head>
<body>
    <div class="jumbotron">
        <div class="container text-center">
            <h1>Techniq Cauldron</h1>
            <p>Learn here anything</p>
        </div>
    </div>
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="#">Cauldron</a>
            </div>
            <ul class="nav navbar-nav">
                <li class="active"><a href="<?php echo site_url("user");?>">Home</a></li>
                <li><a href="<?php echo site_url("course/catalog");?>">Catalog</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="<?php echo site_url("user/myaccount");?>"><span class="glyphicon glyphicon-user"></span> My Account</a></li>
                <li><a href="<?php echo site_url("user/logout");?>"><span></span> Logout</a></li>
            </ul>
        </div>
    </nav>
    <div class="container">
        <?php $attributes = array('class' => 'form-horizontal', 'role' => 'form');
        echo form_open('', $attributes)?>
        <div class="form-group">
            <label class="control-label col-sm-2" for="email">Email:</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="email" value="<?php echo $email ?>">
            </div>
            <div class="col-sm-4">
                <a href="">Edit password</a>
            </div>
        </div>
        <div class="form-group">
            <label class="control-label col-sm-2" for="email">User Type:</label>
            <div class="col-sm-6">
                <input type="text" class="form-control"  name="firstname" value="<?php echo $usertype ?>">
            </div>
        </div>
        <div class="form-group">
            <label class="control-label col-sm-2" for="email">First Name:</label>
            <div class="col-sm-6">
                <input type="text" class="form-control"  name="firstname" value="<?php echo $firstname ?>">
            </div>
        </div>
        <div class="form-group">
            <label class="control-label col-sm-2" for="email">Last Name:</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="lastname" value="<?php echo $lastname ?>">
            </div>
        </div>
        <div class="form-group"> 
            <div class="col-sm-offset-2 col-sm-6">
                <button type="submit" class="btn btn-info">UPDATE</button>
            </div>
        </div>
        <?php echo form_close();?>
    </div>
</body>
</html>

