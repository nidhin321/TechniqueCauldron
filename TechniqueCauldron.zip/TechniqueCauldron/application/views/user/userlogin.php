<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="<?php echo base_url("assets/bootstrap-3.3.7/css/bootstrap.min.css")?>">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="<?php echo base_url("assets/bootstrap-3.3.7/js/bootstrap.min.js")?>"></script>
</head>
<body> 
<div class="jumbotron">
    <div class="container text-center">
            <h1>Techniq Cauldron</h1>
            <p>Learn here anything</p>
    </div>
</div>
<div class="container">
    <h3>Don't have an account? <a href="<?php echo site_url("user/signup");?>">Sign up</a>.</h3>
    <?php $attributes = array('class' => 'form-horizontal', 'role' => 'form');
    echo form_open('', $attributes)?>
        <div class="form-group">
            <label class="control-label col-sm-2" for="email">Email:</label>
            <div class="col-sm-6">
                <input type="email" class="form-control" id="email" name="username" placeholder="Enter email">
            </div>
        </div>
        <div class="form-group">
            <label class="control-label col-sm-2" for="pwd">Password:</label>
            <div class="col-sm-6">
                <input type="password" class="form-control" id="pwd" name="password" placeholder="Enter password">
            </div>
        </div>
        <div class="form-group"> 
            <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-info">Submit</button>
        </div>
  </div>
    <?php echo form_close(); ?>
</div>   
</body>
</html>

