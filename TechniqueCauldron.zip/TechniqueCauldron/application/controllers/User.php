<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {
        
    public function __construct() {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->helper(array('form','url'));
        $this->load->library('form_validation');
        $this->load->library('session');
    }
    public function index()
    {
            $this->load->view('user/mycourse');
    }
    public function logout(){
            $this->session->unset_userdata('user_id');
            $this->session->sess_destroy();
            header('Location:'.site_url());
    }
    public function signup()
    {
            $view_data= array();
            $this->form_validation->set_rules('email', 'Email Address', 'trim|valid_email|is_unique[users.email]|callback_required_anyone');
            $this->form_validation->set_message('is_unique', "%s already exists.");
            $this->form_validation->set_rules('password', 'Password', 'required|trim|min_length[6]');
            $this->form_validation->set_rules('confirmpassword', 'Confirm Password', 'required|matches[password]');
            if ($this->form_validation->run()){
                $email=$this->input->post('email');
                $data = array('usertype'=>2,'email' => $email,'firstname' => $this->input->post('firstname'),'lastname' => $this->input->post('lastname'),'password'=>md5($this->input->post('password')));
                $id=$this->User_model->replace_temp_user($data);
                if($id){
                   $confirm_link=  site_url("user/confirm_email/".md5($id)."/$email");
                   $view_data['confirmlink'] = 'Please click the following link to verify your email: <br><a href="'.$confirm_link.'">'.$confirm_link.'</a>';
                }
            }
            $this->load->view('user/signup',$view_data);
    }
    public function confirm_email($user_id_md5=NULL,$email=NULL){
            if(!empty($user_id_md5)&&!empty($email)){
                if(!$this->User_model->get_user(array('email'=>$email)))
                {
                    $user=$this->User_model->get_temp_user(array('email'=>$email));
                    $insert_data['email']=$user['email'];
                    $insert_data['password']=$user['password'];
		    $insert_data['usertype']=2;
                    $insert_data['firstname']=$user['firstname'];
                    $insert_data['lastname']=$user['lastname'];
                    $insert_data['userstatus']=1;
                    $this->User_model->insert_user($insert_data);
                }
            }
    }
    public function required_anyone(){
            $this->form_validation->set_message('required_anyone', 'Please enter email' );
            $email=$this->input->post('email');
            return !empty($email);
    }
    public function myaccount(){
            $accountdetails = $this->User_model->userDetailsById(1);
            print_r($accountdetails);
            foreach($accountdetails as $row)
            {
                $data['email']=$row->email;
                $data['usertype'] = $row->usertype;
                $data['firstname'] = $row->firstname;
                $data['lastname'] = $row->lastname;	
             }
            $this->load->view('user/myaccount',$data);
        }
}
?>

