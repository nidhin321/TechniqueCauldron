<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
        public function __construct(){
            parent::__construct();
            $this->load->model('User_model');
            $this->load->helper(array('form','url'));
            $this->load->library('form_validation');
            $this->load->library('session');
	}
	public function index()
	{ 
		$this->load->view('user/login');
	}
        public function customerlogin(){  
                $this->form_validation->set_rules('password', 'Password', 'trim|required|callback_validate');
                if($this->form_validation->run()){
                    redirect ('user');
                }
                $this->load->view('user/userlogin');
        }
        public function validate($password){
            $res=$this->User_model->get_by_username($this->input->post('username'));
            if($res&&$res->password==md5($password)){
                $this->set_logged_in($res->id,$res->email,$res->firstname.' '.$res->lastname);
                return TRUE;
            }
            $this->form_validation->set_message('validate', 'Incorrect username or password!');
            return FALSE;
        }
        public function set_logged_in($user_id,$email,$name=''){
            $sess_array = array();
            $sess_array = array('user_id'=>$user_id,'user_email'=>$email,'name'=>$name);
            $this->session->set_userdata('logged_in', $sess_array);
        }
}
