<?php
/**
 * Description of user_model
 * @author Arun Krishnan G <arunkg@vitalect-india.com>
 */
class User_model extends CI_Model {
    public function __construct(){
        parent::__construct();
	$this->load->database();
    }
    public function get_by_username($username){
        $res=$this->db->select('id,password,email,firstname,lastname')->where('email',$username)->get('users');
        if($res->num_rows()>0){
            $ret=$res->result();
            return $ret[0];}
        else 
            return false;
    }
    public function replace_temp_user($data){
        return $this->db->replace('temp_user', $data)?$this->db->insert_id():false;
    }
    public function get_user($data)
    {
        $res=$this->db->get_where('users',$data);
        
        if($res->num_rows()>0)
        {
            $ret=$res->result_array();
            return $ret[0];
        }
        return false;
    }
    public function get_temp_user($data)
    {
        $res=$this->db->get_where('temp_user',$data);
        
        if($res->num_rows()>0)
        {
            $ret=$res->result_array();
            return $ret[0];
        }
        return false;
    }
    public function insert_user($data){
        return $this->db->insert('users', $data)?$this->db->insert_id():false;
    }
    public function userDetailsById($userId){
        $this -> db -> select('email, usertype,firstname, lastname');
        $this -> db -> from('users');
        $this -> db -> where('id', $userId);
        $query = $this -> db -> get();

        if($query -> num_rows() == 1)
        {
                return $query->result();
        }
        else
        {
                return false;
        }
    }
}
?>

