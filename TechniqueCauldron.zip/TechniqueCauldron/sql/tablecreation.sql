CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) unsigned NOT NULL,
  `email` varchar(300) CHARACTER SET latin1 DEFAULT NULL,
  `password` varchar(300) CHARACTER SET latin1 DEFAULT NULL,
  `firstname` varchar(300) CHARACTER SET latin1 DEFAULT NULL,
  `lastname` varchar(300) CHARACTER SET latin1 DEFAULT NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `users`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;

ALTER TABLE `users` ADD `usertype` INT(11) NOT NULL AFTER `id`;

INSERT INTO `users` (`id`, `email`, `password`, `firstname`, `lastname`, `userstatus`) VALUES (NULL, 'arunkg@vitalect-india.com', 'b85e4f97ce94194b2f2062b0a40172c5', 'Arun Krishnan', 'G', '1');


CREATE TABLE IF NOT EXISTS `usertypes` (
	`id` int(11) unsigned NOT NULL,
	`usertype` varchar(50) CHARACTER SET latin1 DEFAULT NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

ALTER TABLE `usertypes`
  ADD PRIMARY KEY (`id`)
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;

INSERT INTO `usertypes` ('id','usertype') VALUES (NULL,'Admin'),(NULL,'Learner'),(NULL,'Instructor');





